wav_file = 'N1.wav'; 
lpccs = msf_lpcc(wav_file,16000,'order',10);