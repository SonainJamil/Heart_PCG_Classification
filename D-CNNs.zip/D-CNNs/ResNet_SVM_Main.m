clc
clear all;
close all;
Test_ResNet_Feature=[];
Test_ResNet_Label=[];
%Import Dataset
imdsTrain = imageDatastore('Test','IncludeSubfolders',true,'FileExtensions',{'.jpg','.png','.tif','.tiff','.jpeg','.bmp'},'LabelSource','foldernames');
%Divide into train and test
a=imdsTrain.Files;
%Extract features and labels of training dataset
for i=1:length(a)
        display(i)
        [I,info] = readimage( imdsTrain , i);
        g=imresize(I,[224,224]);
        B=size(g);
        C=length(B);
        if C==2
            g=cat(3,g,g,g);
        else
            g=g;
        end
        net=resnet50;
        net.Layers;
        layer='fc1000';
        F=activations(net,g,layer,'outputAs','rows');
        L=info.Label;
        Test_ResNet_Feature=[Test_ResNet_Feature;F];
        Test_ResNet_Label=[Test_ResNet_Label;L];
end
save('Test_ResNet_Feature','Test_ResNet_Feature')
save('Test_ResNet_Label','Test_ResNet_Label')
