clc
clear all;
close all;

Train_AlexNet_Feature=[];
Train_AlexNet_Label=[];
ds = imageDatastore('Train','IncludeSubfolders',true,'FileExtensions',{'.jpg','.png','.tif','.tiff','.jpeg'},'LabelSource','foldernames');
a=ds.Files;
for i=1:length(a)
        [I,info] = readimage( ds , i);
        r=imresize(I,[227,227]);
        %r=cat(3,g,g,g);
        disp(i)
        net=alexnet;
        net.Layers;
        layer='fc7';
        F=activations(net,r,layer,'outputAs','rows');
        L=info.Label;
        Train_AlexNet_Feature=[Train_AlexNet_Feature;F];
        Train_AlexNet_Label=[Train_AlexNet_Label;L];
end
save('Train_AlexNet_Feature','Train_AlexNet_Feature')
save('Train_AlexNet_Label','Train_AlexNet_Label')

Test_AlexNet_Feature=[];
Test_AlexNet_Label=[];
ds = imageDatastore('Test','IncludeSubfolders',true,'FileExtensions',{'.jpg','.png','.tif','.tiff','.jpeg'},'LabelSource','foldernames');
a=ds.Files;
for i=1:length(a)
        [I,info] = readimage( ds , i);
        r=imresize(I,[227,227]);
        %r=cat(3,g,g,g);
        disp(i)
        net=alexnet;
        net.Layers;
        layer='fc7';
        F=activations(net,r,layer,'outputAs','rows');
        L=info.Label;
        Test_AlexNet_Feature=[Test_AlexNet_Feature;F];
        Test_AlexNet_Label=[Test_AlexNet_Label;L];
end
save('Test_AlexNet_Feature','Test_AlexNet_Feature')
save('Test_AlexNet_Label','Test_AlexNet_Label')
