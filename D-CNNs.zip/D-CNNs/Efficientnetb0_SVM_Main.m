clc
clear all;
close all;
Test_Efficientnetb0_Feature=[];
Test_Efficientnetb0_Label=[];
%Import Dataset
imdsTrain = imageDatastore('Test','IncludeSubfolders',true,'FileExtensions',{'.jpg','.png','.tif','.tiff','.jpeg','.bmp'},'LabelSource','foldernames');
a=imdsTrain.Files;
%Extract features and labels of training dataset
for i=1:length(a)
        display(i)
        [I,info] = readimage( imdsTrain , i);
        g=imresize(I,[224,224]);
        B=size(g);
        C=length(B);
        if C==2
            g=cat(3,g,g,g);
        else
            g=g;
        end
        net=efficientnetb0;
        net.Layers;
        layer='efficientnet-b0|model|head|dense|MatMul';
        F=activations(net,g,layer,'outputAs','rows');
        L=info.Label;
        Test_Efficientnetb0_Feature=[Test_Efficientnetb0_Feature;F];
        Test_Efficientnetb0_Label=[Test_Efficientnetb0_Label;L];
end
save('Test_Efficientnetb0_Feature','Test_Efficientnetb0_Feature')
save('Test_Efficientnetb0_Label','Test_Efficientnetb0_Label')
