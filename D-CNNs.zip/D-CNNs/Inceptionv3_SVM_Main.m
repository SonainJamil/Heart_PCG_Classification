clc
clear all;
close all;
Test_Inceptionv3_Feature=[];
Test_Inceptionv3_Label=[];
%Import Dataset
imdsTrain = imageDatastore('Test','IncludeSubfolders',true,'FileExtensions',{'.jpg','.png','.tif','.tiff','.jpeg','.bmp'},'LabelSource','foldernames');
a=imdsTrain.Files;
%Extract features and labels of training dataset
for i=1:length(a)
        display(i)
        [I,info] = readimage( imdsTrain , i);
        g=imresize(I,[299,299]);
        B=size(g);
        C=length(B);
        if C==2
            g=cat(3,g,g,g);
        else
            g=g;
        end
        net=inceptionv3;
        net.Layers;
        layer='predictions';
        F=activations(net,g,layer,'outputAs','rows');
        L=info.Label;
        Test_Inceptionv3_Feature=[Test_Inceptionv3_Feature;F];
        Test_Inceptionv3_Label=[Test_Inceptionv3_Label;L];
end
save('Test_Inceptionv3_Feature','Test_Inceptionv3_Feature')
save('Test_Inceptionv3_Label','Test_Inceptionv3_Label')

